﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using Newtonsoft.Json;

namespace OnLineChallenge
{
    public enum TipoOnLineChallenge { Make, Model, Version, Vehicles };
    public class OnLineChallenge<T>
    {
        
        public  static List<T> SendRequest(TipoOnLineChallenge tipo, string query, string endpoint = "http://desafioonline.webmotors.com.br/api/OnlineChallenge/")
        {
            List<T> result = new List<T>();
            using (var httpClient = new HttpClient())
            {
                string url = endpoint + tipo.ToString();

                UriBuilder uri = new UriBuilder(url);
                uri.Query = query;
                using (var response = httpClient.GetAsync(uri.Uri).Result)
                {
                    string apiResponse = response.Content.ReadAsStringAsync().Result;
                    result = JsonConvert.DeserializeObject<List<T>>(apiResponse);
                }
            }
            return result;
        }
    }
}
