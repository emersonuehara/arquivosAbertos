﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OnLineChallenge.Model
{
    public class Version
    {
        public int ModelID { get; set; }
        public int ID { get; set; }
        public string Name { get; set; }

    }
}
