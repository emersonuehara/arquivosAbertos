﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OnLineChallenge.Model
{
    public class Model
    {
        public int MakeID { get; set; }
        public int ID { get; set; }
        public string Name { get; set; }
    }
}
