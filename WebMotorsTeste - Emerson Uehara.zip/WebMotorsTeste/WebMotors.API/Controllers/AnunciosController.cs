﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Webmotors.Negocios;
using Webmotors.Negocios.DTO;
using Webmotors.BD;

namespace Webmotors.API
{
    [Route("api/[controller]")]
    [Microsoft.AspNetCore.Cors.EnableCors("AllowAll")]
    public class AnunciosController : ControllerBase
    {

        Anuncios anuncios = null;

        public AnunciosController(AnuncioBDBase banco)
        {
            anuncios = new Anuncios(banco);
        }


        [HttpGet("{id}")]
        public Anuncio Get(int id)
        {
            return anuncios.ConsultarAnuncio(id);
        }

        // POST api/values
        [HttpPost]
         public void Post([FromBody]Anuncio anuncio)
        {
             anuncios.InserirAnuncio(anuncio);
        }


        [HttpPut("{id}")]
        public Anuncio Put([FromBody]Anuncio anuncio)
        {

            anuncios.AtualizarAnuncio(anuncio);

            return anuncio;
        }

        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            anuncios.DeletarAnuncio(id);
        }
    }
}
