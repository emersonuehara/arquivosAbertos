﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Webmotors.Negocios;

namespace WebMotors.Anuncios.API.Controllers
{
    [Route("api/[controller]")]
    public class VehicleController : Controller
    {
        Vehicles vehicles = null;
        public VehicleController(IConfiguration configuration)
        {
            vehicles = new Vehicles();
        }

        // GET api/values
        [HttpGet]
        public List<Webmotors.Negocios.DTO.Vehicle> Get()
        {
            
            throw new Exception("Not Implemented");
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public List<Webmotors.Negocios.DTO.Vehicle> Get(int id)
        {
            return vehicles.Consultar(id);
        }

       
    }
}
