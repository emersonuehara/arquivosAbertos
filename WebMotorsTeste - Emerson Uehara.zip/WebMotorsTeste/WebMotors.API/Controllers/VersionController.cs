﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Webmotors.Negocios;

namespace WebMotors.Anuncios.API.Controllers
{
    [Route("api/[controller]")]
    public class VersionController : Controller
    {
        Versions versions = null;
        public VersionController(IConfiguration configuration)
        {
            versions = new Versions();
        }

        // GET api/values
        [HttpGet]
        public List<Webmotors.Negocios.DTO.Version> Get()
        {
            
            throw new Exception("Not Implemented");
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public List<Webmotors.Negocios.DTO.Version> Get(int id)
        {
            return versions.Consultar(id);
        }

       
    }
}
