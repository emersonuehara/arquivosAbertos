﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Webmotors.Negocios;

namespace WebMotors.Anuncios.API.Controllers
{
    [Route("api/[controller]")]
    public class MakeController : Controller
    {
        Makes makes = null;
        public MakeController(IConfiguration configuration)
        {
            makes = new Makes();
        }

        // GET api/values
        [HttpGet]
        public List<Webmotors.Negocios.DTO.Make> Get()
        {
            return makes.Consultar();
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            throw new  Exception("Not Implemented");
        }

       
    }
}
