﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Webmotors.Negocios;

namespace WebMotors.Anuncios.API.Controllers
{
    [Route("api/[controller]")]
    public class ModelController : Controller
    {
        Models models = null;
        public ModelController(IConfiguration configuration)
        {
            models = new Models();
        }

        // GET api/values
        [HttpGet]
        public List<Webmotors.Negocios.DTO.Model> Get()
        {
            
            throw new Exception("Not Implemented");
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public List<Webmotors.Negocios.DTO.Model> Get(int id)
        {
            return models.Consultar(id);
        }

       
    }
}
