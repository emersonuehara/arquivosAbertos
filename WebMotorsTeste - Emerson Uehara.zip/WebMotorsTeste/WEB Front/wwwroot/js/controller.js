﻿var app = angular.module('mainApp', []);
app.controller('CRUDWebmotorsController', function ($scope, $http ) {



    $scope.btnConsultarCLick = function (emp) {
            window.location.href = "http://localhost:58158/api/Anuncios/" + $scope.txtID;
    }

    $scope.btnModelCLick = function (emp) {
        window.location.href = "http://localhost:58158/api/Model/" + $scope.txtID;
    }

    $scope.btnMakeCLick = function (emp) {
        window.location.href = "http://localhost:58158/api/Make" ;
    }

    $scope.btnVersionCLick = function (emp) {
        window.location.href = "http://localhost:58158/api/Version/" + $scope.txtID;
    }

    $scope.btnVehicleCLick = function (emp) {
        window.location.href = "http://localhost:58158/api/Vehicle/" + $scope.txtID;
    }

    $scope.btnIncluirCLick = function (emp) {
        debugger;

        var dataJson = {
                   ID: $scope.txtID,
                  marca:"vw",
                  modelo:"polo",
                 versao:"beats",
                  ano:2019,
                   quilometragem:1000,
                  observacao:"novo"
            }
        

        var request = $http({
            method: "POST",
            url: "http://localhost:58158/api/Anuncios",
           // dataType: "json",//optional
           // headers: { "Content-Type": "multipart/form-data" },
          // headers: { "Content-Type":'application/json; charset = utf - 8'},
          //  headers: { "Content-Type": 'application/json'},
            headers: { "Access-Control-Allow-Origin" : "*"},
           // headers: {
            //    'Accept': '*/*', 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS, PUT, PATCH, DELETE', 'Access-Control-Allow-Headers': 'origin,X-Requested-With,content-type,accept',
           //     'Access-Control-Allow-Credentials': 'true'   },
         //   contentType: "application/json; charset=utf-8",
            data: JSON.stringify(dataJson)     // { "value": $scope.txtID  }
        }).success(function (response) {
            debugger;
            alert(response);
            }).error(function (data, status, header, config) {
                alert("Data: " + data +
                    "<hr />status: " + status +
                    "<hr />headers: " + header +
                    "<hr />config: " + config);
            });
    }




    $scope.btnAlterarCLick = function (emp) {
        debugger;

        var dataJson = {
            ID: $scope.txtID,
            marca: "vw",
            modelo: "polo",
            versao: "xxxxxxxx",
            ano: 2019,
            quilometragem: 9000,
            observacao: "novo 2"
        }


        var request = $http({
            method: "PUT",
            url: "http://localhost:58158/api/Anuncios",
            headers: { "Access-Control-Allow-Origin": "*" },
            data: JSON.stringify(dataJson)     
        }).success(function (response) {
            debugger;
            alert(response);
        }).error(function (data, status, header, config) {
            alert("Data: " + data +
                "<hr />status: " + status +
                "<hr />headers: " + header +
                "<hr />config: " + config);
        });
    }
    


});
