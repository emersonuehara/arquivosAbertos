﻿using System;
using Webmotors.BD.Model;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Webmotors.BD
{
    public class AnuncioBDBase   //<B> where B: class //: IBancoDeDados
    {

        private BDConfig _configBD;

        public AnuncioBDBase(BDConfig configBD)
        {
            _configBD = configBD;
        }

        public Anuncio Retonar(int iD)    //where T : class
        {
            
            using (var contexto = new BDContexto(_configBD))
            {

                // Create
                Console.WriteLine("Insere objeto no banco");
                var dbCons = contexto.tb_AnuncioWebmotors.FirstOrDefaultAsync(i => i.ID == iD);

                return dbCons.Result;
            }

        }

        public List<T> Listar<T>(string campo, string valor)
        {
            //var filter = Builders<T>.Filter.Eq(campo, valor);
            //return database.GetCollection<T>(_settings.BooksCollectionName).Find(filter).ToList();
            throw new Exception("Not Implemented");
        }

        public void Criar<T>(T objInserir) where T : class
        {
            //database.GetCollection<T>(_settings.BooksCollectionName).InsertOne(objInserir);
            //return objInserir;
            using (var db = new  BDContexto(_configBD))
            {
                // Create
                Console.WriteLine("Insere objeto no banco");
                db.Add<T>(objInserir);
                db.SaveChanges();

            }

        }

        public void Atualizar(Anuncio objAlterar)
        {
            using (var contexto = new BDContexto(_configBD))
            {

                // Create
                Console.WriteLine("Insere objeto no banco");
                var dbCons = contexto.tb_AnuncioWebmotors.FirstOrDefaultAsync(i => i.ID == objAlterar.ID);

                if (dbCons.Result != null)
                {
                    contexto.Entry(dbCons.Result).CurrentValues.SetValues(objAlterar);
                    contexto.SaveChanges();
                }


            }
        }

        public void Remover(int iD)
        {
            using (var contexto = new BDContexto(_configBD))
            {

                // Create
                Console.WriteLine("Insere objeto no banco");
                var dbCons = contexto.tb_AnuncioWebmotors.FirstOrDefaultAsync(i => i.ID == iD);

                if (dbCons.Result != null)
                {
                    contexto.Remove(dbCons.Result);
                    contexto.SaveChanges();
                }


            }
        }

    }
}
