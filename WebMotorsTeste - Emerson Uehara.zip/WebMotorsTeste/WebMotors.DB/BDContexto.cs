﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Webmotors.BD.Model;

namespace Webmotors.BD
{
    class BDContexto: DbContext
    {
        string connectionString = null;
        public BDContexto(BDConfig config)
        {
            connectionString = config.ConnectionString;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder options)
            => options.UseSqlServer(connectionString);
          //  => options.UseSqlServer("Data Source = LAPTOP-2SDR69BU;Initial Catalog = teste_webmotors; Trusted_Connection=True;");


        public DbSet<Webmotors.BD.Model.Anuncio> tb_AnuncioWebmotors { get; set; }

    }
}
