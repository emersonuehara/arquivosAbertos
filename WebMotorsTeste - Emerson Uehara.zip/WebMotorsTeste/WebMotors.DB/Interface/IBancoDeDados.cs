﻿using System;
using System.Collections.Generic;
using System.Text;
using Webmotors.BD.Model;

namespace Webmotors.BD
{
    public interface IBancoDeDados
    {

        T Retonar<T>(string valor, string campo = "codigo", string collectionName = null);

        List<T> Listar<T>(string campo, string valor);

        T Criar<T>(T objInserir);

        void Atualizar<T>(string campo, string valor, T objAlterar);

        void Remover<T>(string campo, string valor);
    }
}
