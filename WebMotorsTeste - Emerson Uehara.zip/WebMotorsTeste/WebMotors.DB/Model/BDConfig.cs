﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Webmotors.BD.Model
{
    public class BDConfig
    {
        public string ConnectionString { get; set; }
    }
}
