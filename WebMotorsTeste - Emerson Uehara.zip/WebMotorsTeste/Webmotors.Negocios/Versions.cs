﻿using System;
using System.Collections.Generic;
using System.Text;
using olc = OnLineChallenge.Model;

namespace Webmotors.Negocios
{
    public class Versions
    {

        public List<DTO.Version> Consultar(int iD)
        {
            List<olc.Version> versionListOLC =  OnLineChallenge.OnLineChallenge<OnLineChallenge.Model.Version>.SendRequest(OnLineChallenge.TipoOnLineChallenge.Version, "ModelID=" + iD);

            List<DTO.Version> listVersionDTO = new List<DTO.Version>();
            foreach(var versionOLC in versionListOLC)
            {
                listVersionDTO.Add(
                    new DTO.Version() {
                         ID = versionOLC.ID,
                         Name = versionOLC.Name,
                         ModelID = versionOLC.ModelID
                    } 
                );
            }

            return listVersionDTO;
        }
    }
}
