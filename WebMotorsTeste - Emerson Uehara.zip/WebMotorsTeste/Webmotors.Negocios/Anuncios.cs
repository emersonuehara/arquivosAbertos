﻿using System;
using Webmotors.BD;
using Microsoft.Extensions.Configuration;

namespace Webmotors.Negocios
{
    public class Anuncios
    {
        AnuncioBDBase _banco = null;
        public Anuncios(AnuncioBDBase banco)
        {
            _banco = banco;
        }
        
        public void InserirAnuncio(DTO.Anuncio anuncioDTO)
        {
            try
            {
                #region Regras de Negocio
                //Coloquei essa validacao so para simular regras de negocio
                if (String.IsNullOrWhiteSpace(anuncioDTO.marca) || String.IsNullOrWhiteSpace(anuncioDTO.modelo))
                    throw new Exception("Modelo ou marca nulo/branco");

                #endregion Regras de Negocio


                #region Converterndo objs

                BD.Model.Anuncio anuncioBD = new BD.Model.Anuncio();
                anuncioBD.marca = anuncioDTO.marca;
                anuncioBD.modelo = anuncioDTO.modelo;
                anuncioBD.observacao = anuncioDTO.observacao;
                anuncioBD.quilometragem = anuncioDTO.quilometragem;
                anuncioBD.versao = anuncioDTO.versao;


                #endregion Convertendo objs


                #region insere no banco

                _banco.Criar<Webmotors.BD.Model.Anuncio>(anuncioBD);

                #endregion insere no banco

            }
            catch (Exception err)
            {
                throw err;
            }


        }


        public void AtualizarAnuncio(DTO.Anuncio anuncioDTO)
        {
            try
            {
                #region Regras de Negocio
                //Coloquei essa validacao so para simular regras de negocio
                if (String.IsNullOrWhiteSpace(anuncioDTO.marca) || String.IsNullOrWhiteSpace(anuncioDTO.modelo))
                    throw new Exception("Modelo ou marca nulo/branco");

                #endregion Regras de Negocio    


                #region Converterndo objs

                BD.Model.Anuncio anuncioBD = new BD.Model.Anuncio();
                anuncioBD.ID = anuncioDTO.ID;
                anuncioBD.marca = anuncioDTO.marca;
                anuncioBD.modelo = anuncioDTO.modelo;
                anuncioBD.observacao = anuncioDTO.observacao;
                anuncioBD.quilometragem = anuncioDTO.quilometragem;
                anuncioBD.versao = anuncioDTO.versao;


                #endregion Convertendo objs


                #region insere no banco

                _banco.Atualizar(anuncioBD);

                #endregion insere no banco
            }
            catch (Exception err)
            {
                throw err;
            }
        }

        public void DeletarAnuncio(int iD)
        {
            try
            {
                _banco.Remover(iD);
            }
            catch (Exception err)
            {
                throw err;
            }
        }


        public DTO.Anuncio ConsultarAnuncio(int iD)
        {
            try
            {
                BD.Model.Anuncio anuncioBD = _banco.Retonar(iD);

                if (anuncioBD != null)
                {
                    return new DTO.Anuncio()
                    {
                        ano = anuncioBD.ano,
                        ID = anuncioBD.ID,
                        marca = anuncioBD.marca,
                        modelo = anuncioBD.modelo,
                        observacao = anuncioBD.observacao,
                        quilometragem = anuncioBD.quilometragem,
                        versao = anuncioBD.versao
                    };
                }

                return null;
            }
            catch (Exception err)
            {
                throw err;
            }
        }
    }
}
