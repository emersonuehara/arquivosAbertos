﻿using System;
using System.Collections.Generic;
using System.Text;
using olc = OnLineChallenge.Model;

namespace Webmotors.Negocios
{
    public class Makes
    {

        public List<DTO.Make> Consultar()
        {
            List<olc.Make> makeListOLC =  OnLineChallenge.OnLineChallenge<OnLineChallenge.Model.Make>.SendRequest(OnLineChallenge.TipoOnLineChallenge.Make, "");

            List<DTO.Make> listMakeDTO = new List<DTO.Make>();
            foreach(var makeOLC in makeListOLC)
            {
                listMakeDTO.Add(
                    new DTO.Make() {
                         ID = makeOLC.ID,
                         Name = makeOLC.Name
                    } 
                );
            }

            return listMakeDTO;
        }
    }
}
