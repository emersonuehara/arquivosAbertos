﻿using System;
using System.Collections.Generic;
using System.Text;
using olc = OnLineChallenge.Model;

namespace Webmotors.Negocios
{
    public class Vehicles
    {

        public List<DTO.Vehicle> Consultar(int iD)
        {
            List<olc.Vehicle> vehicleListOLC =  OnLineChallenge.OnLineChallenge<OnLineChallenge.Model.Vehicle>.SendRequest(OnLineChallenge.TipoOnLineChallenge.Vehicles, "Page=" + iD);

            List<DTO.Vehicle> listVehicleDTO = new List<DTO.Vehicle>();
            foreach(var vehicleOLC in vehicleListOLC)
            {
                listVehicleDTO.Add(
                    new DTO.Vehicle() {
                        ID = vehicleOLC.ID,
                        Make = vehicleOLC.Make,
                        Model = vehicleOLC.Model,
                        Version = vehicleOLC.Version,
                        Color = vehicleOLC.Color,
                        Image = vehicleOLC.Image,
                        KM = vehicleOLC.KM,
                        Price = vehicleOLC.Price,
                        YearFab = vehicleOLC.YearFab,
                        YearModel = vehicleOLC.YearModel
                    } 
                );
            }

            return listVehicleDTO;
        }
    }
}
