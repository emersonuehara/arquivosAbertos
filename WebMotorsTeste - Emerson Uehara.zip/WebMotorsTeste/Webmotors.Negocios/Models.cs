﻿using System;
using System.Collections.Generic;
using System.Text;
using olc = OnLineChallenge.Model;
using Microsoft.Extensions.Configuration;

namespace Webmotors.Negocios
{
    public class Models
    {


        public List<DTO.Model> Consultar(int iD)
        {
            List<olc.Model> modelListOLC =  OnLineChallenge.OnLineChallenge<OnLineChallenge.Model.Model>.SendRequest(OnLineChallenge.TipoOnLineChallenge.Model, "MakeID=" + iD);

            List<DTO.Model> listModelDTO = new List<DTO.Model>();
            foreach(var modelOLC in modelListOLC)
            {
                listModelDTO.Add(
                    new DTO.Model() {
                         ID = modelOLC.ID,
                         Name = modelOLC.Name,
                         MakeID = modelOLC.MakeID
                    } 
                );
            }

            return listModelDTO;
        }
    }
}
